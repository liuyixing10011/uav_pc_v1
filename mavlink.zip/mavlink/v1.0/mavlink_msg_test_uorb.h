
// TEST UORB PACKING

#define MAVLINK_MSG_ID_TEST_UORB 177

typedef struct __mavlink_test_uorb_t
{
    uint64_t timestamp; ///< Time since system boot
    uint64_t shuai;
} mavlink_test_uorb_t;

#define MAVLINK_MSG_ID_TEST_UORB_LEN 25
#define MAVLINK_MSG_ID_177_LEN 25

#define MAVLINK_MSG_ID_TEST_UORB_CRC 105
#define MAVLINK_MSG_ID_177_CRC 105



#define MAVLINK_MESSAGE_INFO_TEST_UORB { \
    "TEST_UORB", \
    2, \
    {  { "timestamp", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_test_uorb_t, timestamp) }, \
         { "shuai", NULL, MAVLINK_TYPE_UINT64_T, 0, 4, offsetof(mavlink_test_uorb_t, shuai) }, \
     } \
}


/**
 * @brief Pack a test_uorb message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param timestamp Time since system boot
 * @param shuai Minimum distance the sensor can measure in centimeters
 * @param max_distance Maximum distance the sensor can measure in centimeters
 * @param current_distance Current distance reading
 * @param type Type from MAV_TEST_UORB enum.
 * @param id Onboard ID of the sensor
 * @param orientation Direction the sensor faces from MAV_SENSOR_ORIENTATION enum.
 * @param covariance Measurement covariance in centimeters, 0 for unknown / invalid readings
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_test_uorb_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint64_t timestamp, uint64_t shuai)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TEST_UORB_LEN];
    _mav_put_uint64_t(buf, 0, timestamp);
    _mav_put_uint64_t(buf, 4, shuai);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TEST_UORB_LEN);
#else
    mavlink_test_uorb_t packet;
    packet.timestamp = timestamp;
    packet.shuai = shuai;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TEST_UORB;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_TEST_UORB_LEN, MAVLINK_MSG_ID_TEST_UORB_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif
}

/**
 * @brief Pack a test_uorb message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param timestamp Time since system boot
 * @param shuai Minimum distance the sensor can measure in centimeters
 * @param max_distance Maximum distance the sensor can measure in centimeters
 * @param current_distance Current distance reading
 * @param type Type from MAV_TEST_UORB enum.
 * @param id Onboard ID of the sensor
 * @param orientation Direction the sensor faces from MAV_SENSOR_ORIENTATION enum.
 * @param covariance Measurement covariance in centimeters, 0 for unknown / invalid readings
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_test_uorb_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint64_t timestamp,uint64_t shuai)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TEST_UORB_LEN];
    _mav_put_uint64_t(buf, 0, timestamp);
    _mav_put_uint64_t(buf, 4, shuai);
    memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TEST_UORB_LEN);
#else
    mavlink_test_uorb_t packet;
    packet.timestamp = timestamp;
    packet.shuai = shuai;
    memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TEST_UORB;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_TEST_UORB_LEN, MAVLINK_MSG_ID_TEST_UORB_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif
}

/**
 * @brief Encode a test_uorb struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param test_uorb C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_test_uorb_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_test_uorb_t* test_uorb)
{
    return mavlink_msg_test_uorb_pack(system_id, component_id, msg, test_uorb->timestamp, test_uorb->shuai);
}

/**
 * @brief Encode a test_uorb struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param test_uorb C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_test_uorb_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_test_uorb_t* test_uorb)
{
    return mavlink_msg_test_uorb_pack_chan(system_id, component_id, chan, msg, test_uorb->timestamp, test_uorb->shuai);
}

/**
 * @brief Send a test_uorb message
 * @param chan MAVLink channel to send the message
 *
 * @param timestamp Time since system boot
 * @param shuai Minimum distance the sensor can measure in centimeters
 * @param max_distance Maximum distance the sensor can measure in centimeters
 * @param current_distance Current distance reading
 * @param type Type from MAV_TEST_UORB enum.
 * @param id Onboard ID of the sensor
 * @param orientation Direction the sensor faces from MAV_SENSOR_ORIENTATION enum.
 * @param covariance Measurement covariance in centimeters, 0 for unknown / invalid readings
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_test_uorb_send(mavlink_channel_t chan, uint64_t timestamp, uint64_t shuai)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TEST_UORB_LEN];
    _mav_put_uint64_t(buf, 0, timestamp);
    _mav_put_uint64_t(buf, 4, shuai);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TEST_UORB, buf, MAVLINK_MSG_ID_TEST_UORB_LEN, MAVLINK_MSG_ID_TEST_UORB_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TEST_UORB, buf, MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif
#else
    mavlink_test_uorb_t packet;
    packet.timestamp = timestamp;
    packet.shuai = shuai;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TEST_UORB, (const char *)&packet, MAVLINK_MSG_ID_TEST_UORB_LEN, MAVLINK_MSG_ID_TEST_UORB_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TEST_UORB, (const char *)&packet, MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_TEST_UORB_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_test_uorb_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t timestamp, uint64_t shuai, uint16_t max_distance, uint16_t current_distance, uint8_t type, uint8_t id, uint8_t orientation, uint8_t covariance)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint64_t(buf, 0, timestamp);
    _mav_put_uint64_t(buf, 4, shuai);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TEST_UORB, buf, MAVLINK_MSG_ID_TEST_UORB_LEN, MAVLINK_MSG_ID_TEST_UORB_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TEST_UORB, buf, MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif
#else
    mavlink_test_uorb_t *packet = (mavlink_test_uorb_t *)msgbuf;
    packet->timestamp = timestamp;
    packet->shuai = shuai;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TEST_UORB, (const char *)packet, MAVLINK_MSG_ID_TEST_UORB_LEN, MAVLINK_MSG_ID_TEST_UORB_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TEST_UORB, (const char *)packet, MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE TEST_UORB UNPACKING


/**
 * @brief Get field timestamp from test_uorb message
 *
 * @return Time since system boot
 */
static inline uint32_t mavlink_msg_test_uorb_get_timestamp(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field shuai from test_uorb message
 *
 * @return Minimum distance the sensor can measure in centimeters
 */
static inline uint16_t mavlink_msg_test_uorb_get_shuai(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  4);
}

/**
 * @brief Get field max_distance from test_uorb message
 *
 * @return Maximum distance the sensor can measure in centimeters
 */
static inline uint16_t mavlink_msg_test_uorb_get_max_distance(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  6);
}

/**
 * @brief Get field current_distance from test_uorb message
 *
 * @return Current distance reading
 */
static inline uint16_t mavlink_msg_test_uorb_get_current_distance(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  8);
}

/**
 * @brief Get field type from test_uorb message
 *
 * @return Type from MAV_TEST_UORB enum.
 */
static inline uint8_t mavlink_msg_test_uorb_get_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  10);
}

/**
 * @brief Get field id from test_uorb message
 *
 * @return Onboard ID of the sensor
 */
static inline uint8_t mavlink_msg_test_uorb_get_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  11);
}

/**
 * @brief Get field orientation from test_uorb message
 *
 * @return Direction the sensor faces from MAV_SENSOR_ORIENTATION enum.
 */
static inline uint8_t mavlink_msg_test_uorb_get_orientation(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  12);
}

/**
 * @brief Get field covariance from test_uorb message
 *
 * @return Measurement covariance in centimeters, 0 for unknown / invalid readings
 */
static inline uint8_t mavlink_msg_test_uorb_get_covariance(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  13);
}

/**
 * @brief Decode a test_uorb message into a struct
 *
 * @param msg The message to decode
 * @param test_uorb C-struct to decode the message contents into
 */
static inline void mavlink_msg_test_uorb_decode(const mavlink_message_t* msg, mavlink_test_uorb_t* test_uorb)
{
#if MAVLINK_NEED_BYTE_SWAP
    test_uorb->timestamp = mavlink_msg_test_uorb_get_timestamp(msg);
    test_uorb->shuai = mavlink_msg_test_uorb_get_shuai(msg);

#else
    memcpy(test_uorb, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_TEST_UORB_LEN);
#endif
}
